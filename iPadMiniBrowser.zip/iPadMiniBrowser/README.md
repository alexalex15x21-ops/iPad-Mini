# iPad Mini Browser
Lightweight Android WebView browser that presents itself as an iPad Mini 6 (desktop layout, 744x1133 CSS px).
Build: push to GitHub -> Actions -> Artifacts -> iPadMini-Browser-APK.
Test: open https://www.whatismybrowser.com
