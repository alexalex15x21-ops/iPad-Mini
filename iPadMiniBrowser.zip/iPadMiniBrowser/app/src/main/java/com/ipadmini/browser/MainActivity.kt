package com.ipadmini.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * iPad Mini 6 browser: desktop-class UA (iPadOS reports a Mac UA),
 * 744x1133 CSS px portrait / 1133x744 landscape, DPR 2, touch points 5.
 */
class MainActivity : Activity() {

    companion object {
        const val UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) " +
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
        const val HOME = "https://www.google.com"
        const val IPAD_W = 744   // iPad Mini 6 portrait CSS width
        const val IPAD_H = 1133  // iPad Mini 6 portrait CSS height
    }

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var root: FrameLayout
    private var scriptHandler: ScriptHandler? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    private fun isLandscape() =
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun spoofScript(): String {
        val w = if (isLandscape()) IPAD_H else IPAD_W
        val h = if (isLandscape()) IPAD_W else IPAD_H
        return """
(function(){
  try {
    var W=$w, H=$h;
    function def(o,p,v){ try{ Object.defineProperty(o,p,{get:function(){return v},configurable:true}); }catch(e){} }
    def(navigator,'platform','MacIntel');
    def(navigator,'vendor','Apple Computer, Inc.');
    def(navigator,'maxTouchPoints',5);
    def(navigator,'userAgentData',undefined);
    def(screen,'width',W); def(screen,'height',H);
    def(screen,'availWidth',W); def(screen,'availHeight',H);
    def(window,'devicePixelRatio',2);
    function fix(){
      var head=document.head||document.documentElement; if(!head) return;
      var m=document.querySelector('meta[name=viewport]');
      if(!m){ m=document.createElement('meta'); m.name='viewport'; head.appendChild(m); }
      var c='width='+W+', minimum-scale=0.1, maximum-scale=5, user-scalable=yes';
      if(m.getAttribute('content')!==c) m.setAttribute('content',c);
    }
    fix();
    new MutationObserver(fix).observe(document.documentElement,{childList:true,subtree:true});
    document.addEventListener('DOMContentLoaded',fix);
  } catch(e) {}
})();
"""
    }

    private fun installScript() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            scriptHandler?.remove()
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, spoofScript(), setOf("*"))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        root = FrameLayout(this)
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ---- Top bar ----
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#F2F2F7"))
            setPadding(px(4), px(4), px(4), px(4))
        }
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            minWidth = 0; minimumWidth = 0
            setPadding(px(10), 0, px(10), 0)
            setOnClickListener { onClick() }
        }
        val back = btn("◀") { if (web.canGoBack()) web.goBack() }
        val fwd = btn("▶") { if (web.canGoForward()) web.goForward() }
        val reload = btn("⟳") { web.reload() }
        urlBar = EditText(this).apply {
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            textSize = 14f
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_GO) {
                    load(text.toString()); hideKeyboard(); true
                } else false
            }
        }
        val go = btn("Go") { load(urlBar.text.toString()); hideKeyboard() }
        bar.addView(back); bar.addView(fwd); bar.addView(reload)
        bar.addView(urlBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(go)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }

        // ---- WebView ----
        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = UA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(false)
            textZoom = 100
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        installScript()

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return false
                return s != "http" && s != "https" && s != "about" // block intent:// etc.
            }
            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                urlBar.setText(url)
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    v.evaluateJavascript(spoofScript(), null) // fallback
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                progress.progress = p
                progress.visibility = if (p in 1..99) View.VISIBLE else View.GONE
            }
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                customView = view; customCallback = cb
                root.addView(view, FrameLayout.LayoutParams(-1, -1))
                column.visibility = View.GONE
            }
            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customCallback?.onCustomViewHidden()
                customView = null; customCallback = null
                column.visibility = View.VISIBLE
            }
        }

        column.addView(bar)
        column.addView(progress, LinearLayout.LayoutParams(-1, px(3)))
        column.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val start = intent?.dataString ?: savedInstanceState?.getString("url") ?: HOME
        load(start)
    }

    private fun load(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") ->
                "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
            else -> "https://$t"
        }
        web.loadUrl(url)
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
        web.requestFocus()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        installScript()          // new W/H for next page loads
        web.reload()             // apply iPad size for the current page
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("url", web.url)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
